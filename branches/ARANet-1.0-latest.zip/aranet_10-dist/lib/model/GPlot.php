<?php

/**
 * Subclass for representing a row from the 'aranet_plot' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GPlot extends BaseGPlot
{
}
