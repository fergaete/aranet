<?php

/**
 * Subclass for performing query and update operations on the 'aranet_graphic' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GraphicPeer extends BaseGraphicPeer
{
}
