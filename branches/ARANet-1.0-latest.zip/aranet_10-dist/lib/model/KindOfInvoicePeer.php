<?php

/**
 * Subclass for performing query and update operations on the 'aranet_kind_of_invoice' table.
 *
 * 
 *
 * @package lib.model
 */ 
class KindOfInvoicePeer extends BaseKindOfInvoicePeer
{
}
