<?php

/**
 * Subclass for performing query and update operations on the 'aranet_default_indicator' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DefaultIndicatorPeer extends BaseDefaultIndicatorPeer
{
}
