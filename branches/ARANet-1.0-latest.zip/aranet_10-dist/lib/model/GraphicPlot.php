<?php

/**
 * Subclass for representing a row from the 'aranet_graphic_plot' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GraphicPlot extends BaseGraphicPlot
{
}
