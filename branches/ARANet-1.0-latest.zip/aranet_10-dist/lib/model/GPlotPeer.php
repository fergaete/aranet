<?php

/**
 * Subclass for performing query and update operations on the 'aranet_plot' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GPlotPeer extends BaseGPlotPeer
{
}
