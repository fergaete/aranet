<?php

/**
 * Subclass for performing query and update operations on the 'aranet_indicator' table.
 *
 * 
 *
 * @package lib.model
 */ 
class IndicatorPeer extends BaseIndicatorPeer
{
}
