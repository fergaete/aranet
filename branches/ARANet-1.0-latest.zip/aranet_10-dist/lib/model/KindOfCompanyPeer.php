<?php

/**
 * Subclass for performing query and update operations on the 'aranet_kind_of_company' table.
 *
 * @package    aranet
 * @subpackage lib.model
 * @author     Pablo Sánchez <pablo.sanchez@aranova.es>
 * @version    SVN: $Id: KindOfCompanyPeer.php 3 2008-08-06 07:48:19Z pablo $
 */

class KindOfCompanyPeer extends BaseKindOfCompanyPeer
{
}
