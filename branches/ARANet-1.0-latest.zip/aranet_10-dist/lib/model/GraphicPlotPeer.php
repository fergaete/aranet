<?php

/**
 * Subclass for performing query and update operations on the 'aranet_graphic_plot' table.
 *
 * 
 *
 * @package lib.model
 */ 
class GraphicPlotPeer extends BaseGraphicPlotPeer
{
}
