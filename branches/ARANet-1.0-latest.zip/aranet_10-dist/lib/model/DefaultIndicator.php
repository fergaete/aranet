<?php

/**
 * Subclass for representing a row from the 'aranet_default_indicator' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DefaultIndicator extends BaseDefaultIndicator
{
}
