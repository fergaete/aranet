<?php

/**
 * Subclass for performing query and update operations on the 'aranet_expense_item' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ExpenseItemPeer extends BaseExpenseItemPeer
{
}
