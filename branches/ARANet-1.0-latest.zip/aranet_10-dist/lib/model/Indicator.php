<?php

/**
 * Subclass for representing a row from the 'aranet_indicator' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Indicator extends BaseIndicator
{
}
