<?php include_partial('stats', array('budget' => $budget)) ?>
