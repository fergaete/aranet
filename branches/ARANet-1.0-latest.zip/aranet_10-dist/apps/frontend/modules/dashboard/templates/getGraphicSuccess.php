<img src="/dashboard/showGraphic?graphic_id=<?php echo $sf_params->get('graphic_id', -1) ?>" alt="<?php echo __('Graphic') 
?>" style="width:100%"/>
