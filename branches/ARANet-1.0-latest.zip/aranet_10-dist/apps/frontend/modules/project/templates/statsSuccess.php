<?php use_helper('Number', 'NumberExtended') ?>
<?php include_partial('stats', array('project' => $project)) ?>
