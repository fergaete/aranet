<div id="projectMilestoneAddEdit" style="margin-top: 10px;">
</div>
<div id="projectViewMilestones" class="windowFrame"><?php include_partial('project/milestone_list', array('project' => $project)) ?>
</div>