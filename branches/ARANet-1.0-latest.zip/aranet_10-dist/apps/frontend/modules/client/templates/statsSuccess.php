<?php include_partial('stats', array('client' => $client)) ?>
