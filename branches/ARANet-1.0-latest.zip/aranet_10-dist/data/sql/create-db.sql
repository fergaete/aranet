drop database if exists aranet;
create database aranet;
