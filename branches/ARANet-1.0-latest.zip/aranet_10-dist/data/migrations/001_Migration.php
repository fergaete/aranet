<?php

class Migration001 extends sfMigration {
  public function up() 
  {
  }

  public function down() 
  {
  }
}
